const char* ssid     = "kamehouse";
const char* password = "Oliver-jeremy-051177";
const char* hostname = "ESP8266_1";

IPAddress ip(192, 168, 1, 200);
IPAddress gateway(192, 168, 1, 1);
IPAddress subnet(255, 255, 255, 0);
